#include <WiFiS3.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ===== WiFi Credentials =====
const char* ssid     = "*************";
const char* password = "*************";

// ===== ThingsBoard Setup =====
const char* thingsboardServer = "*******************";
const char* accessToken       = "*******************";
const int   mqttPort          = ****;

// ===== Pin Definitions =====
#define SOIL_PIN   A0
#define RELAY_PIN  3
#define DHTPIN     2
#define DHTTYPE    DHT11

// ===== OLED Setup =====
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ===== Soil Moisture Calibration =====
const int moistureMin = 1000; // Dry
const int moistureMax = 100; // Wet
const int moistureThreshold = 50; // %

WiFiClient wifiClient;
PubSubClient client(wifiClient);
DHT dht(DHTPIN, DHTTYPE);

// ===== WiFi Connect =====
void connectToWiFi() {
  Serial.print("Connecting to WiFi");
  while (WiFi.status() != WL_CONNECTED) {
    WiFi.begin(ssid, password);
    delay(300);
    Serial.print(".");
  }
  Serial.println("\n✅ WiFi Connected!");
}

// ===== ThingsBoard Connect =====
void connectToThingsBoard() {
  while (!client.connected()) {
    Serial.print("Connecting to ThingsBoard...");
    if (client.connect("SmartIrrigationDevice", accessToken, NULL)) {
      Serial.println("✅ Connected!");
    } else {
      Serial.print("❌ Failed, rc=");
      Serial.println(client.state());
      delay(300);
    }
  }
}

// ===== OLED Display Update =====
void updateOLED(int rawValue, int moisturePercent, float temperature, float humidity) {
  display.clearDisplay();  // Clear once before drawing

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(0, 0);
  display.print("Raw: ");
  display.print(rawValue);
  display.print("   ");   // Spaces to clear leftover digits

  display.setCursor(0, 16);
  display.print("Soil: ");
  display.print(moisturePercent);
  display.print("%   ");

  display.setCursor(0, 32);
  display.print("Temp: ");
  display.print(temperature, 1);
  display.print(" C   ");

  display.setCursor(0, 50);
  display.print("Humidity: ");
  display.print(humidity, 1);
  display.print(" %   ");

  display.display();  // Refresh once after all drawing
}

void setup() {
  Serial.begin(9600);

  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW); // Ensure pump off initially

  dht.begin();

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("⚠ OLED not found!");
  }

  connectToWiFi();
  client.setServer(thingsboardServer, mqttPort);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    connectToWiFi();
  }

  if (!client.connected()) {
    connectToThingsBoard();
  }

  client.loop();

  // Read soil moisture sensor
  int rawValue = analogRead(SOIL_PIN);
  int moisturePercent = map(rawValue, moistureMax, moistureMin, 0, 100);
  moisturePercent = constrain(moisturePercent, 0, 100);

  // Read DHT sensor
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("⚠ Failed to read DHT11!");
    temperature = 0;
    humidity = 0;
  }

  // Control pump relay based on soil moisture threshold
  if (moisturePercent < moistureThreshold) {
    digitalWrite(RELAY_PIN, LOW); // Pump ON
  } else {
    digitalWrite(RELAY_PIN, HIGH);  // Pump OFF
  }

  // Update OLED display
  updateOLED(rawValue, moisturePercent, temperature, humidity);

  // Send data to ThingsBoard
  String payload = "{";
  payload += "\"soilMoisture\":" + String(moisturePercent) + ",";
  payload += "\"rawValue\":" + String(rawValue) + ",";
  payload += "\"temperature\":" + String(temperature) + ",";
  payload += "\"humidity\":" + String(humidity);
  payload += "}";

  client.publish("v1/devices/me/telemetry", payload.c_str());

  Serial.print("Raw: ");
  Serial.print(rawValue);
  Serial.print("  Moisture %: ");
  Serial.println(moisturePercent);
  Serial.println(payload);

  delay(500);
}
